#include "Report.h"
#include <iostream>
#include<string>
using namespace std;

int main() {

    Report report;
    Manager A("1", "Alice", "Female", "2024-2-7", "Manager", 12345, 230);
    Technician B("2", "Bob", "Male", "2023-2-7", "Technician", 67890);
    Salesperson C("3", "Charlie", "Male", "2023-3-4", "Salesperson", 123, 4567);
    Manager D("4", "john", "Male", "2024-3-7", "Manager", 13579, 23);
    Technician E("5", "mike", "Male", "2021-9-5", "Technician", 24680);
    Salesperson F("6", "Char", "Male", "2008-7-4", "Salesperson", 3867, 4567);



    report.insert(&A);
    report.insert(&B);
    report.insert(&C);
    report.insert(&D);
    report.insert(&E);
    report.insert(&F);

    cout << "Employee Payment Report:" << endl;
    report.print();

    vector<Employee*> managers = report["Manager"];
    cout << "Managers:" << endl;
    for (Employee* emp : managers) {
        cout << *emp << ", Payment: " << emp->get_pay() << endl;
    }

    return 0;

}

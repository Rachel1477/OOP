
#ifndef REPORT_H
#define REPORT_H

#include "Employee.h"
#include <map>
#include <vector>

class Report {
private:
    map<string, vector<Employee*>> employees_Position;

public:
    void insert(Employee* emp);
    void print() const;
    vector<Employee*> operator[](const string position) const;
};

#endif // REPORT_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

class Employee {
    protected:
        string id;
        string name;
        string gender;
        string enroll_date;
        string position;
        double salary;

    public:
        Employee() {}
        Employee(string id, string name, string gender, string enroll_date, string position, double salary);

        virtual ~Employee() {}

        virtual double get_pay() { return -1; };
        string read_position();
        friend  ostream& operator<<(ostream& out, const Employee& e);
    };

class Manager : public Employee
{
private:
    double bonus;
public:

    double get_pay();
    Manager(string id, string name, string gender, string enroll_date, string position, double salary ,double bonus): Employee(id, name, gender, enroll_date, position, salary), bonus(bonus){}

};
class Technician : public Employee
{

public:

    double get_pay();
    Technician(string id, string name, string gender, string enroll_date, string position, double salary) : Employee(id, name, gender, enroll_date, position, salary) {}

};


class  Salesperson : public Employee
{
private:
    double profit;
public:

    double get_pay();
    Salesperson(string id, string name, string gender, string enroll_date, string position, double salary, double profit) : Employee(id, name, gender, enroll_date, position, salary), profit(profit) {}

};







#include "Report.h"
#include <iostream>

void Report::insert(Employee* emp) {
    employees_Position[emp->read_position()].push_back(emp);
}

void Report::print() const {
    for (const auto& entry : employees_Position) {
        cout << "Position: " << entry.first << endl;
        for (Employee* emp : entry.second) {
            cout << *emp << ", Payment: " << emp->get_pay() << endl;

        }
        cout << "----------------------------" << endl << endl;
    }

    double max_pay = -1;
    double min_pay = 999999999;
    for (const auto& entry : employees_Position) {
        for (Employee* emp : entry.second) {
            double pay = emp->get_pay();
            if (pay > max_pay) max_pay = pay;
            if (pay < min_pay) min_pay = pay;
        }
    }
    cout << "Max Payment: " << max_pay << endl;
    cout << "Min Payment: " << min_pay << endl<<endl;
    cout << "------------------------------------" << endl;
}

vector<Employee*> Report::operator[](const  string position) const {
    auto it = employees_Position.find(position);
    if (it != employees_Position.end()) {
        return it->second;
    }
    return  vector<Employee*>();
}



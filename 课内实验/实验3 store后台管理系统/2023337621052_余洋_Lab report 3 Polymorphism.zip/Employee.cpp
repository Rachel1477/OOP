#include "Employee.h"


ostream& operator<<(ostream& out, const Employee& e) {
    out << "ID: " << e.id
        << ", Name: " << e.name
        << ", Gender: " << e.gender
        << ", Enroll Date: " << e.enroll_date
        << ", Position: " << e.position
        << ", Salary: " << e.salary;
    return out;
}
Employee::Employee(string id, string name, string gender, string enroll_date, string position, double salary):id(id), name(name), gender(gender), enroll_date(enroll_date), position(position), salary(salary) {}
string Employee::read_position()
{
    return position;
}
double Manager::get_pay()
{
    return salary + bonus;
}

double Technician::get_pay()
{
    return salary ;
}

double Salesperson::get_pay()
{
    return salary + profit*0.05;
}


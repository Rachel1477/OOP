#include "elevator.h"
int main()
{
	elevator A;
	A.start();
}
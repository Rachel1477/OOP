#include <iostream>
#include <stdexcept> 

class QueueFullException : public std::exception {
public:
    const char* what() const throw() {
        return "Queue is full";
    }
};

class QueueEmptyException : public std::exception {
public:
    const char* what() const throw() {
        return "Queue is empty";
    }
};

template <typename T>
class FixedSizeQueue {
private:
    T* queueArray; 
    int front; 
    int rear; 
    int capacity;
    bool full;

public:
    FixedSizeQueue(int size) : capacity(size), front(0), rear(0), full(false) {
        queueArray = new T[capacity];
    }

    ~FixedSizeQueue() {
        delete[] queueArray;
    }

    void enqueue(const T& item) {
        if (isFull()) {
            throw QueueFullException();
        }
        queueArray[rear] = item;
        rear = (rear + 1) % capacity;
        full = (rear == front);
    }

    T dequeue() {
        if (isEmpty()) {
            throw QueueEmptyException();
        }
        T item = queueArray[front];
        front = (front + 1) % capacity;
        full = false;
        return item;
    }

    bool isEmpty() const {
        return front == rear && !full;
    }

    bool isFull() const {
        return full;
    }
};

int main() {
    FixedSizeQueue<int> queue(10);

    try {

        for (int i = 0; i < 11; ++i) {
            queue.enqueue(i);
        }
    }
    catch (const QueueFullException& e) {
        std::cerr << e.what() << std::endl;
    }

    try {

        while (true) {
            int item = queue.dequeue();
            std::cout << "Dequeued: " << item << std::endl;
        }
    }
    catch (const QueueEmptyException& e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
#include <algorithm>
#include <cstddef>
#include <string>
#include<iostream>
using namespace std;
template <typename T, size_t N>
T find_max(T const (&arr)[N]) {
    T max_val = arr[0];
    for (size_t i = 1; i < N; ++i) {
        if (arr[i] > max_val) {
            max_val = arr[i];
        }
    }
    return max_val;
}

template <typename T>
T find_max(T const* arr, size_t N) {
    T max_val = arr[0];
    for (size_t i = 1; i < N; ++i) {
        if (arr[i] > max_val) {
            max_val = arr[i];
        }
    }
    return max_val;
}

int main()
{
    int arr1[] = { 1, 2, 3, 4, 5 };
    int max1 = find_max(arr1);

    char arr2[] = { 'a', 'b', 'c', 'd', 'e' };
    char max2 = find_max(arr2);

    float arr3[] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
    float max3 = find_max(arr3);

    double arr4[] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
    double max4 = find_max(arr4);

    long arr5[] = { 1, 2, 3, 4, 5 };
    long max5 = find_max(arr5);

    const char* arr6[] = { "as," "b", "c", "d", "e", "f" };
    const char* max6 = find_max(arr6);
    cout << max1 << "  " << max2 << "  " << max3 << "  " << max4 << "   " << max5 << "   " << max6 << endl;
}
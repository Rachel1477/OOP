#include <iostream>
#include <vector>
using namespace std;
template<typename T>
class Queue {
private:
    vector<T> data;
    int front;
    int rear;
    int capacity;

public:
    Queue(int size = 10) {
        data.resize(size);
        front = -1;
        rear = -1;
        capacity = size;
    }

    void clear() {
        front = -1;
        rear = -1;
    }

    bool isEmpty() const {
        return front == -1;
    }

    bool isFull() const {
        return (rear + 1) % capacity == front;
    }

    void enqueue(const T& item) {
        if (isFull()) {
            cout << "Queue is full. Cannot enqueue." << endl;
            return;
        }
        if (isEmpty()) {
            front = rear = 0;
        }
        else {
            rear = (rear + 1) % capacity;
        }
        data[rear] = item;
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty. Cannot dequeue." << endl;
            return;
        }
        if (front == rear) {
            clear();
        }
        else {
            front = (front + 1) % capacity;
        }
    }

    T first() const {
        if (isEmpty()) {
            throw  runtime_error("Queue is empty.");
        }
        return data[front];
    }
};

int main() {
    Queue<int> q(5);


    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);

    // Test first
    cout << "First element: " << q.first() << endl;

    // Test dequeue
    cout << "the dequeue element is :" << q.first() << endl;
    q.dequeue();

    // Test isEmpty
    while (!q.isEmpty()) {
        q.dequeue();
    }
    cout << "Is queue empty? " << (q.isEmpty() ? "Yes" : "No") << endl;

    // Test isFull
    Queue<int> q2(1);
    q2.enqueue(10);
    cout << "Is queue full? " << (q2.isFull() ? "Yes" : "No") << endl;

    // Test clear
    q2.clear();
    cout << "Is queue empty after clear? " << (q2.isEmpty() ? "Yes" : "No") << endl;

    return 0;
}


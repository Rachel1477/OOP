#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Worker {
private:
    const char* name;
    int age;
    double salary;

public:
    Worker(const char* Name, int Age, double Wage) : name(Name), age(Age), salary(Wage) {}

    void display() {
        cout << "Name: " << name << ", Age: " << age << ", Salary: " << salary << endl;
    }

    friend bool compareWorker(const Worker& a, const Worker& b);
};

bool compareWorker(const Worker& a, const Worker& b) {
    return a.salary < b.salary;
}

int main() {
    vector<Worker> vec1 = { Worker("A", 30, 12345), Worker("B", 45, 56789), Worker("Charlie",40, 87655) };
    vector<Worker> vec2 = { Worker("D", 40, 50000), Worker("E", 28, 51000), Worker("F", 40, 51000) };
    vector<Worker> mergedVec;

    mergedVec.insert(mergedVec.end(), vec1.begin(), vec1.end());
    mergedVec.insert(mergedVec.end(), vec2.begin(), vec2.end());


    sort(mergedVec.begin(), mergedVec.end(), compareWorker);

    cout << "Merged vector: " << endl;
    for ( auto& worker : mergedVec) {
        worker.display();
    }

    return 0;
}

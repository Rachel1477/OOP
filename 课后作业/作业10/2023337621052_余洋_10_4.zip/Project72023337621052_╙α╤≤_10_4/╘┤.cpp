#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> vector1 = { 1, 2, 3, 4, 5 };

    vector<int> vector2 = { 4, 7, 8, 9, 10 };

    vector<int> mergedVector;

    mergedVector.reserve(vector1.size() + vector2.size());

    mergedVector.insert(mergedVector.end(), vector1.begin(), vector1.end());
    mergedVector.insert(mergedVector.end(), vector2.begin(), vector2.end());

    sort(mergedVector.begin(), mergedVector.end());

    cout << "Sorted merged vector: ";
    for (const auto& num : mergedVector) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
